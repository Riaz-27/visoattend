import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controller/auth_controller.dart';
import '../../models/user_model.dart';
import '../../views/pages/reset_password_page.dart';
import '../../views/widgets/custom_button.dart';
import '../../controller/cloud_firestore_controller.dart';
import '../../helper/constants.dart';
import '../../helper/functions.dart';
import '../widgets/custom_text_form_field.dart';

import 'face_register_page.dart';

class LoginRegisterPage extends StatelessWidget {
  const LoginRegisterPage({Key? key, this.isSignUp = false}) : super(key: key);

  final bool isSignUp;

  @override
  Widget build(BuildContext context) {
    // final validEmail = RegExp(
    //     r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
    final validEmail = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w]{2,5}');

    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final userIdController = TextEditingController();
    final passwordController = TextEditingController();
    final confirmPasswordController = TextEditingController();

    final authController = Get.find<AuthController>();
    final cloudFirestoreController = Get.find<CloudFirestoreController>();

    final formKey = GlobalKey<FormState>();

    String? emailValidatorString;
    String? userValidatorString;

    // void signUpUser() {
    //   final name = nameController.text.trim();
    //   final email = emailController.text.trim();
    //   final userId = userIdController.text.trim();
    //   final password = passwordController.text.trim();
    //   if (name.isNotEmpty &&
    //       userId.isNotEmpty &&
    //       email.isNotEmpty &&
    //       password.isNotEmpty) {
    //     final newUser = IsarUser()
    //       ..name = name
    //       ..userId = userId
    //       ..password = password;
    //     userDatabaseController.checkUser(userId).then(
    //       (userFound) {
    //         nameController.text = '';
    //         userIdController.text = '';
    //         passwordController.text = '';
    //         if (!userFound) {
    //           Get.offAll(
    //             () => FaceRegisterPage(user: newUser),
    //           );
    //         }
    //       },
    //     );
    //   }
    // }

    // void loginUser() {
    //   final userId = userIdController.text.trim();
    //   final password = passwordController.text.trim();
    //   // cloudFirestoreController.getUserData(userId);
    //   userDatabaseController.verifyUser(userId, password).then((userFound) {
    //     if (userFound != null) {
    //       Get.offAll(
    //         () => const ClassroomPage(),
    //       );
    //     }
    //   });
    // }

    Future<void> handleSignInOrSignUp() async {
      final name = nameController.text.trim();
      final password = passwordController.text;
      final userId = userIdController.text.trim();

      String email = emailController.text.trim();
      UserModel? userData;

      if (isSignUp) {
        authController.tempPassword = password;
        final user = UserModel(
          authUid: 'null',
          profilePic:
              'https://firebasestorage.googleapis.com/v0/b/visoattend.appspot.com/o/profile_pics%2Fdefault_profile.jpg?alt=media&token=0ff37477-4ac1-41df-8522-73a5eacceee7',
          userId: userId,
          name: name,
          email: email,
          mobile: '',
          gender: '',
          dob: '',
          batch: '',
          designation: '',
          department: '',
          classrooms: {},
          faceDataFront: [],
          faceDataLeft: [],
          faceDataRight: [],
        );
        hideLoadingDialog();
        Get.to(() => FaceRegisterPage(user: user));
      } else {
        final bool emailValid = validEmail.hasMatch(userId);
        if (emailValid) {
          email = userId;
        } else {
          userData =
              await cloudFirestoreController.getUserDataFromFirestore(userId);
          if (userData == null) {
            email = '';
          } else {
            email = userData.email;
          }
        }
        if (email != '') {
          await authController
              .signInWithEmailAndPassword(
            email: email,
            password: password,
          )
              .then((value) {
            hideLoadingDialog();
            if (!value) {
              errorDialog(
                title: 'Login Failed',
                msg: 'User not found with this credentials.',
              );
            }
          });
          // if (success) {
          //   // cloudFirestoreController.currentUser = userData!;
          //   // Get.offAll(() => const AuthPage());
          // } else {
          //   hideLoadingDialog();
          //   errorDialog(
          //     title: 'Login Failed',
          //     msg: 'User not found with this credentials.',
          //   );
          // }
        } else {
          hideLoadingDialog();
          errorDialog(
            title: 'Login Failed',
            msg: 'User not found with this credentials.',
          );
        }
      }
    }

    Future<void> validateEmail(String email) async {
      final userData =
          await cloudFirestoreController.getUserDataFromFirestoreByEmail(email);
      if (userData != null) {
        emailValidatorString = 'A user with this Email address already exists';
        return;
      }
      emailValidatorString = null;
    }

    Future<void> validateUser(String userId) async {
      final userData =
          await cloudFirestoreController.getUserDataFromFirestore(userId);
      if (userData != null) {
        userValidatorString = 'A user with this User ID already exists';
        return;
      }
      userValidatorString = null;
    }

    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: deviceHeight * 0.025),
        child: Form(
          key: formKey,
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (!isSignUp) ...[
                    SizedBox(
                      width: deviceWidth * 0.55,
                      child: Image.asset('assets/icons/text_icon.png'),
                    ),
                    // Text(
                    //   'VisoAttend',
                    //   style: Get.textTheme.titleLarge!
                    //       .copyWith(fontWeight: FontWeight.bold),
                    // ),
                    verticalGap(deviceHeight * percentGapSmall),
                    Text(
                      'Welcome Back',
                      style: textTheme.bodySmall!.copyWith(
                        fontSize: deviceWidth * 0.035,
                        color: textColorLight,
                      ),
                    ),
                    Text(
                      'Please sign in to continue',
                      style: textTheme.bodySmall!.copyWith(
                        fontSize: deviceWidth * 0.035,
                        color: textColorLight,
                      ),
                    ),
                    verticalGap(deviceHeight * percentGapMedium),
                  ],
                  if (isSignUp) ...[
                    Text(
                      'Create Account',
                      style: textTheme.titleLarge!.copyWith(
                        fontWeight: FontWeight.bold,
                        color: textColorDefault,
                      ),
                    ),
                    verticalGap(deviceHeight * percentGapLarge),
                    CustomTextFormField(
                      labelText: 'Full Name (According to the registration)',
                      controller: nameController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your name.';
                        }
                        if (!RegExp(r'^[a-z A-Z.]+$').hasMatch(value)) {
                          return 'Only letters and space are allowed.';
                        }
                        return null;
                      },
                    ),
                    verticalGap(deviceHeight * percentGapMedium),
                    CustomTextFormField(
                      labelText: 'Email',
                      controller: emailController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your email address.';
                        }
                        if (!validEmail.hasMatch(value)) {
                          return 'Email is not valid.';
                        }
                        return emailValidatorString;
                      },
                    ),
                    verticalGap(deviceHeight * percentGapMedium),
                  ],
                  CustomTextFormField(
                    labelText: isSignUp ? 'Student/Teacher ID' : 'ID / Email',
                    controller: userIdController,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        if (isSignUp) {
                          return 'Please enter your student/teacher ID';
                        }
                        return 'Please enter your student/teacher ID or email';
                      }
                      if (value.length < 5) {
                        return 'ID must have at least 5 characters.';
                      }
                      if (isSignUp) {
                        if (!RegExp(r'^[a-zA-Z0-9]+$').hasMatch(value)) {
                          return 'ID must be letters or number';
                        }
                        return userValidatorString;
                      }
                      return null;
                    },
                  ),
                  verticalGap(deviceHeight * percentGapMedium),
                  CustomTextFormField(
                    labelText: 'Password',
                    controller: passwordController,
                    isPassword: true,
                    maxLines: 1,
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        if (isSignUp) return 'Please enter a password.';
                        return 'Please enter your password.';
                      }
                      if (value.trim().length < 6) {
                        return 'Password must be at least 6 characters';
                      }
                      return null;
                    },
                  ),
                  verticalGap(deviceHeight * percentGapMedium),
                  if (isSignUp) ...[
                    CustomTextFormField(
                      labelText: 'Confirm Password',
                      controller: confirmPasswordController,
                      isPassword: true,
                      maxLines: 1,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please re-enter the password.';
                        }
                        if (passwordController.text != value) {
                          return 'Password do not match';
                        }
                        return null;
                      },
                    ),
                    verticalGap(deviceHeight * percentGapLarge),
                  ],
                  if (!isSignUp) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Get.to(() => const ResetPasswordPage());
                          },
                          child: Text(
                            'Forgotten Password?',
                            style: textTheme.labelMedium!.copyWith(
                              color: colorScheme.secondary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    verticalGap(deviceHeight * percentGapMedium),
                  ],
                  CustomButton(
                    text: isSignUp ? 'Sign Up' : 'Sign In',
                    onPressed: () async {
                      loadingDialog('Please wait...');
                      authController.isLoading = true;
                      await validateEmail(emailController.text);
                      await validateUser(userIdController.text);
                      if (formKey.currentState!.validate()) {
                        await handleSignInOrSignUp();
                      } else {
                        hideLoadingDialog();
                        authController.isLoading = false;
                      }
                    },
                  ),
                  verticalGap(deviceHeight * percentGapSmall),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 5.0),
                        child: Text(
                          isSignUp
                              ? 'Already have an account?'
                              : "Don't have an account?",
                          style: textTheme.labelLarge!.copyWith(
                            color: textColorDefault,
                          ),
                        ),
                      ),
                      TextButton(
                        style: TextButton.styleFrom(padding: EdgeInsets.zero),
                        onPressed: () {
                          authController.isLoading = false;
                          Get.offAll(
                            () => LoginRegisterPage(
                              isSignUp: !isSignUp,
                            ),
                            transition: Transition.cupertino,
                          );
                        },
                        child: Text(
                          isSignUp ? 'Sign In' : 'Sign up',
                          style: textTheme.labelLarge!.copyWith(
                            color: colorScheme.secondary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
