package com.example.visoattend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
